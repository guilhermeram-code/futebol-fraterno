import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Menu, X, Trophy, Calendar, Users, BarChart3, Image, Settings, LogIn, Star, User } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useTournament } from "@/contexts/TournamentContext";
import { useCampaign } from "@/App";
import { trpc } from "@/lib/trpc";

export function Header() {
  const { user, isAuthenticated } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { settings, isLoading } = useTournament();
  const { slug } = useCampaign();

  const navItems = [
    { href: `/${slug}/classificacao`, label: "Classificação", icon: Trophy },
    { href: `/${slug}/jogos`, label: "Jogos", icon: Calendar },
    { href: `/${slug}/jogadores`, label: "Jogadores", icon: User },
    { href: `/${slug}/times`, label: "Times", icon: Users },
    { href: `/${slug}/estatisticas`, label: "Estatísticas", icon: BarChart3 },
    { href: `/${slug}/galeria`, label: "Galeria", icon: Image },
    { href: `/${slug}/patrocinadores`, label: "Patrocinadores", icon: Star },
  ];

  return (
    <header className="bg-secondary text-secondary-foreground sticky top-0 z-50">
      <div className="container py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href={slug ? `/${slug}` : "/"}>
            <div className="flex items-center gap-4 cursor-pointer">
              {isLoading ? (
                <>
                  <div className="h-12 w-12 md:h-16 md:w-16 rounded-full bg-muted animate-pulse border-2 border-primary" />
                  <div>
                    <div className="h-6 w-48 bg-muted animate-pulse rounded mb-1" />
                    <div className="h-4 w-32 bg-muted animate-pulse rounded" />
                  </div>
                </>
              ) : (
                <>
                  <img 
                    src={`${settings.tournamentLogo}?v=${Date.now()}`} 
                    alt={settings.tournamentName} 
                    className="h-12 w-12 md:h-16 md:w-16 rounded-full object-cover border-2 border-primary shadow-lg"
                  />
                  <div>
                    <h1 className="text-xl md:text-2xl font-bold text-gold">{settings.tournamentName}</h1>
                    <p className="text-xs md:text-sm text-muted-foreground">{settings.tournamentSubtitle}</p>
                  </div>
                </>
              )}
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-2">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button variant="ghost" className="text-secondary-foreground hover:text-gold">
                  {item.label}
                </Button>
              </Link>
            ))}

            
            {isAuthenticated && user?.role === "admin" ? (
              <Link href={`/${slug}/admin`}>
                <Button variant="default" className="bg-primary text-primary-foreground">
                  Painel Admin
                </Button>
              </Link>
            ) : (
              <Link href={`/${slug}/admin/login`}>
                <Button variant="default" className="bg-primary text-primary-foreground gap-2">
                  <LogIn className="h-4 w-4" />
                  Entrar
                </Button>
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Menu"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6 text-gold" />
              ) : (
                <Menu className="h-6 w-6 text-gold" />
              )}
            </button>
          </div>
        </div>



        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="lg:hidden mt-4 pb-4 border-t border-white/10 pt-4">
            <div className="flex flex-col gap-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.href} href={item.href}>
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start text-secondary-foreground hover:text-gold hover:bg-white/10 gap-3"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Icon className="h-5 w-5" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
              
              <div className="border-t border-white/10 my-2" />
              
              {isAuthenticated && user?.role === "admin" ? (
                <Link href={`/${slug}/admin`}>
                  <Button 
                    variant="default" 
                    className="w-full bg-primary text-primary-foreground gap-3"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Settings className="h-5 w-5" />
                    Painel Admin
                  </Button>
                </Link>
              ) : (
                <Link href={`/${slug}/admin/login`}>
                  <Button 
                    variant="default" 
                    className="w-full bg-primary text-primary-foreground gap-3"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <LogIn className="h-5 w-5" />
                    Entrar
                  </Button>
                </Link>
              )}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
// Correções do Claude #3 aplicadas - Thu Jan 22 17:24:18 EST 2026

import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { useSlug } from "./useSlug";
import { useCampaign } from "@/App";

export function useAdminAuth() {
  const [, setLocation] = useLocation();
  const slug = useSlug();
  const { campaignId } = useCampaign();
  
  // Verificar se há token no localStorage
  const hasToken = !!localStorage.getItem("admin_token");
  
  const { data: adminUser, isLoading, refetch } = trpc.adminUsers.me.useQuery(
    { campaignId },
    {
    retry: false,
    refetchOnWindowFocus: false,
    enabled: hasToken, // Só fazer query se houver token
  });

  const logout = () => {
    // Limpar token IMEDIATAMENTE (antes de qualquer requisição)
    localStorage.removeItem("admin_token");
    toast.success("Logout realizado com sucesso");
    // Redirecionar para página do campeonato (deslogado)
    setLocation(`/${slug}`);
    // Forçar reload da página para limpar estado
    window.location.href = `/${slug}`;
  };

  return {
    adminUser: adminUser || null,
    isAuthenticated: !!adminUser,
    loading: isLoading,
    logout,
    refetch,
  };
}
